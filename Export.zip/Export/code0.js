gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDplayerObjects1= [];
gdjs.Untitled_32sceneCode.GDplayerObjects2= [];
gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1= [];
gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects2= [];
gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1= [];
gdjs.Untitled_32sceneCode.GDDeliveryTextObjects2= [];
gdjs.Untitled_32sceneCode.GDCounterTextObjects1= [];
gdjs.Untitled_32sceneCode.GDCounterTextObjects2= [];
gdjs.Untitled_32sceneCode.GDWinTextObjects1= [];
gdjs.Untitled_32sceneCode.GDWinTextObjects2= [];
gdjs.Untitled_32sceneCode.GDObstacleObjects1= [];
gdjs.Untitled_32sceneCode.GDObstacleObjects2= [];
gdjs.Untitled_32sceneCode.GDTimerTextObjects1= [];
gdjs.Untitled_32sceneCode.GDTimerTextObjects2= [];
gdjs.Untitled_32sceneCode.GDLoseTextObjects1= [];
gdjs.Untitled_32sceneCode.GDLoseTextObjects2= [];
gdjs.Untitled_32sceneCode.GDRestartTextObjects1= [];
gdjs.Untitled_32sceneCode.GDRestartTextObjects2= [];
gdjs.Untitled_32sceneCode.GDAimArrowObjects1= [];
gdjs.Untitled_32sceneCode.GDAimArrowObjects2= [];
gdjs.Untitled_32sceneCode.GDControlsTextObjects1= [];
gdjs.Untitled_32sceneCode.GDControlsTextObjects2= [];
gdjs.Untitled_32sceneCode.GDShotsTextObjects1= [];
gdjs.Untitled_32sceneCode.GDShotsTextObjects2= [];
gdjs.Untitled_32sceneCode.GDRatingTextObjects1= [];
gdjs.Untitled_32sceneCode.GDRatingTextObjects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.Untitled_32sceneCode.GDplayerObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDeliveryZoneObjects1Objects = Hashtable.newFrom({"DeliveryZone": gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.Untitled_32sceneCode.GDplayerObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDObstacleObjects1Objects = Hashtable.newFrom({"Obstacle": gdjs.Untitled_32sceneCode.GDObstacleObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDObstacleObjects1Objects = Hashtable.newFrom({"Obstacle": gdjs.Untitled_32sceneCode.GDObstacleObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DeliveryText"), gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoseText"), gdjs.Untitled_32sceneCode.GDLoseTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("RatingText"), gdjs.Untitled_32sceneCode.GDRatingTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartText"), gdjs.Untitled_32sceneCode.GDRestartTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("WinText"), gdjs.Untitled_32sceneCode.GDWinTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWinTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWinTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLoseTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLoseTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRestartTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRestartTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRatingTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRatingTextObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(7624172);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(gdjs.evtTools.common.angleBetweenPositions((gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getCenterXInScene()), (gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getCenterYInScene()), gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0)) + 180);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(650);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(1))), (gdjs.RuntimeObject.getVariableNumber(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(0))), 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDplayerObjects1[k] = gdjs.Untitled_32sceneCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).sub(900 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(0)) < 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDplayerObjects1[k] = gdjs.Untitled_32sceneCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DeliveryZone"), gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDplayerObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDeliveryZoneObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9220164);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DeliveryText"), gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1[i].hide(false);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CounterText"), gdjs.Untitled_32sceneCode.GDCounterTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCounterTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCounterTextObjects1[i].getBehavior("Text").setText("DELIVERIES: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))) + "/3");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() >= 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RatingText"), gdjs.Untitled_32sceneCode.GDRatingTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartText"), gdjs.Untitled_32sceneCode.GDRestartTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("WinText"), gdjs.Untitled_32sceneCode.GDWinTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWinTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWinTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRestartTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRestartTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRatingTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRatingTextObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Obstacle"), gdjs.Untitled_32sceneCode.GDObstacleObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDplayerObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDObstacleObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDObstacleObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDObstacleObjects1Objects, false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 3);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TimerText"), gdjs.Untitled_32sceneCode.GDTimerTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTimerTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTimerTextObjects1[i].getBehavior("Text").setText("TIME: " + gdjs.evtTools.common.toString(Math.max(0, Math.ceil(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1))))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) <= 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LoseText"), gdjs.Untitled_32sceneCode.GDLoseTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartText"), gdjs.Untitled_32sceneCode.GDRestartTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLoseTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLoseTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRestartTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRestartTextObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("AimArrow"), gdjs.Untitled_32sceneCode.GDAimArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAimArrowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAimArrowObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDplayerObjects1[0].getCenterXInScene()) + 25);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAimArrowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAimArrowObjects1[i].setY((( gdjs.Untitled_32sceneCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDplayerObjects1[0].getCenterYInScene()) - (gdjs.Untitled_32sceneCode.GDAimArrowObjects1[i].getHeight()) / 2);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAimArrowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAimArrowObjects1[i].setAngle(gdjs.evtTools.common.angleBetweenPositions((( gdjs.Untitled_32sceneCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDplayerObjects1[0].getCenterXInScene()), (( gdjs.Untitled_32sceneCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDplayerObjects1[0].getCenterYInScene()), gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0)) + 180);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ShotsText"), gdjs.Untitled_32sceneCode.GDShotsTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDShotsTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDShotsTextObjects1[i].getBehavior("Text").setText("SHOTS: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) <= 8);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RatingText"), gdjs.Untitled_32sceneCode.GDRatingTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRatingTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRatingTextObjects1[i].getBehavior("Text").setText("⭐⭐⭐");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) > 8);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) <= 12);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RatingText"), gdjs.Untitled_32sceneCode.GDRatingTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRatingTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRatingTextObjects1[i].getBehavior("Text").setText("⭐⭐");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) > 12);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RatingText"), gdjs.Untitled_32sceneCode.GDRatingTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRatingTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRatingTextObjects1[i].getBehavior("Text").setText("⭐");
}
}
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDplayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCounterTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCounterTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWinTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWinTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDObstacleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDObstacleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTimerTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTimerTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLoseTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLoseTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRestartTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRestartTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDControlsTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDControlsTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDShotsTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDShotsTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRatingTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRatingTextObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryZoneObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDeliveryTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCounterTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCounterTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWinTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWinTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDObstacleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDObstacleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTimerTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTimerTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLoseTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLoseTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRestartTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRestartTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAimArrowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDControlsTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDControlsTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDShotsTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDShotsTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRatingTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRatingTextObjects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
