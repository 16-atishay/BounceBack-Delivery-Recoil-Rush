
if (typeof gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects !== "undefined") {
  gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects = {};
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.idToCallbackMap = new Map();
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1= [];
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects2= [];


gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDCenterObjectObjects1Objects = Hashtable.newFrom({"CenterObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDOrbitingObjectObjects1Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDCenterObjectObjects1Objects = Hashtable.newFrom({"CenterObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDOrbitingObjectObjects1Objects = Hashtable.newFrom({"OrbitingObject": gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1});
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !eventsFunctionContext.getArgument("ResetObjectsAfterDeletion");
}
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("CenterObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1);
{gdjs.evtsExt__OrbitingObjects__AnimateEllipticalOrbitingObjects.func(runtimeScene, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDCenterObjectObjects1Objects, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDOrbitingObjectObjects1Objects, eventsFunctionContext.getArgument("OrbitQuantity"), eventsFunctionContext.getArgument("OrbitSpeed"), eventsFunctionContext.getArgument("OrbitDistance"), eventsFunctionContext.getArgument("ObjectRotationSpeed"), eventsFunctionContext.getArgument("StartingOffset"), false, eventsFunctionContext.getArgument("OrbitDistance"), "None", eventsFunctionContext.getArgument("OrbitZvalue"), eventsFunctionContext);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getArgument("ResetObjectsAfterDeletion");
}
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("CenterObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("OrbitingObject"), gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1);
{gdjs.evtsExt__OrbitingObjects__AnimateEllipticalOrbitingObjects.func(runtimeScene, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDCenterObjectObjects1Objects, gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.mapOfGDgdjs_9546evtsExt_9595_9595OrbitingObjects_9595_9595AnimateOrbitingObjects_9546GDOrbitingObjectObjects1Objects, eventsFunctionContext.getArgument("OrbitQuantity"), eventsFunctionContext.getArgument("OrbitSpeed"), eventsFunctionContext.getArgument("OrbitDistance"), eventsFunctionContext.getArgument("ObjectRotationSpeed"), eventsFunctionContext.getArgument("StartingOffset"), true, eventsFunctionContext.getArgument("OrbitDistance"), "None", eventsFunctionContext.getArgument("OrbitZvalue"), eventsFunctionContext);
}
}

}


};

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.func = function(runtimeScene, CenterObject, OrbitingObject, OrbitQuantity, OrbitSpeed, OrbitDistance, ObjectRotationSpeed, OrbitLayer, OrbitZvalue, StartingOffset, ResetObjectsAfterDeletion, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
"CenterObject": CenterObject
, "OrbitingObject": OrbitingObject
},
  _objectArraysMap: {
"CenterObject": gdjs.objectsListsToArray(CenterObject)
, "OrbitingObject": gdjs.objectsListsToArray(OrbitingObject)
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("OrbitingObjects"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("OrbitingObjects"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "OrbitQuantity") return OrbitQuantity;
if (argName === "OrbitSpeed") return OrbitSpeed;
if (argName === "OrbitDistance") return OrbitDistance;
if (argName === "ObjectRotationSpeed") return ObjectRotationSpeed;
if (argName === "OrbitLayer") return OrbitLayer;
if (argName === "OrbitZvalue") return OrbitZvalue;
if (argName === "StartingOffset") return StartingOffset;
if (argName === "ResetObjectsAfterDeletion") return ResetObjectsAfterDeletion;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects2.length = 0;

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects1.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDCenterObjectObjects2.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects1.length = 0;
gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.GDOrbitingObjectObjects2.length = 0;


return;
}

gdjs.evtsExt__OrbitingObjects__AnimateOrbitingObjects.registeredGdjsCallbacks = [];